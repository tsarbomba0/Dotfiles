2006-02-07 release.
--
This dictionary is based on a subset of the original
English wordlist created by Kevin Atkinson for Pspell 
and  Aspell and thus is covered by his original 
LGPL license.  The affix file is a heavily modified
version of the original english.aff file which was
released as part of Geoff Kuenning's Ispell and as 
such is covered by his BSD license.

Thanks to both authors for there wonderful work.

ChangeLog

2006-02-07 nemeth AT OOo

Issue 48060 - add ordinal numbers with COMPOUNDRULE (1st, 11th, 101st etc.)
Issue 29112, 55498 - add NOSUGGEST flags to taboo words
Issue 56755 - add sequitor (non sequitor)
Issue 50616 - add open source words (GNOME, KDE, OOo, OpenOffice.org)
Issue 56389 - add Mozilla words (Mozilla, Firefox, Thunderbird)
Issue 29110 - add okay
Issue 58468 - add advisors
Issue 58708 - add hiragana & katakana
Issue 60240 - add arginine, histidine, monovalent, polymorphism, pyroelectric, pyroelectricity

2005-11-01 dnaber AT OOo

Issue 25797 - add proven, advisor, etc.
